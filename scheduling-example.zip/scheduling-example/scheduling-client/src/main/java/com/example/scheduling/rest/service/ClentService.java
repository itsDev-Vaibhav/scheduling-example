package com.example.scheduling.rest.service;

import com.example.scheduling.db.entities.MyClient;
import com.example.scheduling.rest.dto.MyClientRequest;

public interface ClentService {
	MyClient saveClientMessage(MyClientRequest request);
}
