package com.example.scheduling.db.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CLIENT_TABLE")
@Getter
@Setter
public class MyClient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CLIENT_ID")
	private Integer clientId;
	
	@Column(name = "OBJECT_CREATED_ON")
	private LocalDateTime creationTime;
	
	@Column(name = "CLIENT_MESSAGE")
	private String message;
	
	@Column(name = "CREATED_ON", updatable = false)
	@CreationTimestamp
	private LocalDateTime createdOn;
	
	@Column(name = "CREATED_BY")
	private String createdBy;

	public MyClient() {
		
	}
	
	public MyClient(LocalDateTime creationTime, String message) {
		this.creationTime = creationTime;
		this.message = message;
	}

	public MyClient(LocalDateTime creationTime, String message, String createdBy) {
		this.creationTime = creationTime;
		this.message = message;
		this.createdBy = createdBy;
	}
}
