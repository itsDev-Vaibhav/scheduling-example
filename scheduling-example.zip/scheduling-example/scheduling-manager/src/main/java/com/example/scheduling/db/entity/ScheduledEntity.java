package com.example.scheduling.db.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Schedule_Manager_Data")
@Data
public class ScheduledEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer dataId;
	
	private LocalDateTime creationTime;
	
	private String message;
	
	private Integer flag;
}