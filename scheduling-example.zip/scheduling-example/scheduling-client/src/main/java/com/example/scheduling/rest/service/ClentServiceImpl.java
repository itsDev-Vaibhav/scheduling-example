package com.example.scheduling.rest.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.scheduling.db.entities.MyClient;
import com.example.scheduling.db.repositories.MyClientRepo;
import com.example.scheduling.rest.dto.MyClientRequest;

@Service
public class ClentServiceImpl implements ClentService{
	
	@Autowired
	private MyClientRepo repo;

	@Override
	public MyClient saveClientMessage(MyClientRequest request) {
		MyClient client = new MyClient();
		BeanUtils.copyProperties(request, client);
		if(client.getCreatedBy() == null) {
			client.setCreatedBy("HTTP Rest call");
		}
		return repo.save(client);
	}

}
