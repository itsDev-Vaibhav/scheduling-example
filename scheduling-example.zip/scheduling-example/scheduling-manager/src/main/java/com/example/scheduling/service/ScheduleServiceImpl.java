package com.example.scheduling.service;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.scheduling.db.entity.ScheduledEntity;
import com.example.scheduling.db.repo.ScheduledEntityRepo;

@Service
public class ScheduleServiceImpl implements ScheduleService{
	
	@Autowired
	private ScheduledEntityRepo repo;

	@Override
	public void createSchedule(int i) {
		for (int j = 0; j < i; j++) {
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ScheduledEntity entity = new ScheduledEntity();
			LocalDateTime now = LocalDateTime.now();
			entity.setCreationTime(now);
			entity.setMessage("this is test with schedular and rest " + now.toString());
			entity.setFlag(0);
			repo.save(entity);
		}
		
	}

	@Override
	public int sendSchedule() {
		List<ScheduledEntity> findAll = repo.findByFlag(0);
		if(findAll.size() > 0) {
			List<Integer> dataIdList = new LinkedList<>();
			findAll.forEach(sc -> {
				ScheduleDto req = getDto(sc);
				RestTemplate template = new RestTemplate();
				ResponseEntity<String> postForEntity = template.postForEntity("http://127.0.0.1:9091/client", req, String.class);
				if(postForEntity.getStatusCode() == HttpStatus.CREATED) {
					dataIdList.add(sc.getDataId());
				}
			});
			updateScheduleEntity(dataIdList);
			return dataIdList.size();
		}
		return 0;
	}

	private void updateScheduleEntity(List<Integer> dataIdList) {
		dataIdList.forEach(dt -> {
			repo.updateScheduleEntity(dt);
		});
	}

	private ScheduleDto getDto(ScheduledEntity sc) {
		ScheduleDto dto = new ScheduleDto();
		BeanUtils.copyProperties(sc, dto);
		return dto;
	}
}