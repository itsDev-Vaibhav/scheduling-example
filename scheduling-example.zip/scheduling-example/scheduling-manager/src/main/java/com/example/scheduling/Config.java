package com.example.scheduling;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.example.scheduling.service.ScheduleService;

@Configuration
@EnableScheduling
public class Config {
	
	@Autowired
	private ScheduleService service;
	
	@Scheduled(fixedRate = 3 * 60 * 1000, initialDelay = 2 * 60 * 1000)
	public void saveScheduleEntity() {
		service.createSchedule(10);
		System.out.println("Object inserted to database at : " + LocalDateTime.now());
	}
	
	@Scheduled(fixedRate = 5 * 60 * 1000, initialDelay = 10 * 1000)
	public void sendData() {
		int value = service.sendSchedule();
		System.out.println(value + " Objects are sent to Client at : " + LocalDateTime.now());
	}
}
