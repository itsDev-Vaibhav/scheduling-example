package com.example.scheduling.db.repo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.example.scheduling.db.entity.ScheduledEntity;

public interface ScheduledEntityRepo extends JpaRepository<ScheduledEntity, Serializable> {
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE ScheduledEntity s SET s.flag = 11 where s.dataId = ?1")
	public void updateScheduleEntity(Integer id);
	
	
	List<ScheduledEntity> findByFlag(Integer flag);

}
