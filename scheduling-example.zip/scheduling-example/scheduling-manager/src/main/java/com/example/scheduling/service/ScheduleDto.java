package com.example.scheduling.service;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class ScheduleDto {
	
	private LocalDateTime creationTime;
	private String message;

}
