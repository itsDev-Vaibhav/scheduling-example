package com.example.scheduling.db.repositories;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.scheduling.db.entities.MyClient;

public interface MyClientRepo extends JpaRepository<MyClient, Serializable> {

}
