package com.example.scheduling.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.scheduling.db.entities.MyClient;
import com.example.scheduling.rest.dto.MyClientRequest;
import com.example.scheduling.rest.service.ClentService;

@RestController
public class MyClientController {
	
	@Autowired
	private ClentService service;
	
	
	@PostMapping("/client")
	public ResponseEntity<?> serverPostCall(@RequestBody MyClientRequest request) {
		MyClient saveClientMessage = service.saveClientMessage(request);
		return saveClientMessage.getClientId() != null ? new ResponseEntity<>(HttpStatus.CREATED) : new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
	}
}
