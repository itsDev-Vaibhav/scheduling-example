package com.example.scheduling.service;

public interface ScheduleService {

	void createSchedule(int i);

	int sendSchedule();
	
}
